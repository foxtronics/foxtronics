/**
  ******************************************************************************
  * @file     FXT_OLED.c
  * @author   William De Vos - Foxtronics 2022
  * @version  V1.0
  * @date     12/03/2022 15:28:17
  * @brief    Versatile STM32 OLED library for mono-chromatic and 4-bit GS
  ******************************************************************************
*/

/*NOTES:
 *
HAL_SPI_StateTypeDef {
  HAL_SPI_STATE_RESET = 0x00U, HAL_SPI_STATE_READY = 0x01U, HAL_SPI_STATE_BUSY = 0x02U, HAL_SPI_STATE_BUSY_TX = 0x03U,
  HAL_SPI_STATE_BUSY_RX = 0x04U, HAL_SPI_STATE_BUSY_TX_RX = 0x05U, HAL_SPI_STATE_ERROR = 0x06U
}

*/

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdlib.h>
#include "stm32h7xx_hal.h"
#include "FXT_OLED.h"

/* Variables -----------------------------------------------------------------*/

//ERROR MESSAGE STRINGS
char err_xsize[] = "size_x cannot be lower than 1";
char err_ysize[] = "size_y cannot be lower than 1";
char err_init[] = "SPI Peripheral has not been initialised";
char err_error[] = "SPI Error has occured";

/** Functions ----------------------------------------------------------------*/

//Hardware initaliser for OLED display
//Argument: Pointer to OLED struct
uint8_t OLED_Begin(struct OLED *myDisplay)
{
	//Initialise display depending on which interface has been selected
	switch (myDisplay->Interface)
	{
	case (HARD_SPI): //Hardware SPI Initialisation


			return 1;
			break;
	case (SOFT_SPI): //Software SPI Initialisation


			return 1;
			break;
	case (PAR_8): //Hardware SPI Initialisation


			return 1;
			break;
	case (PAR_16): //Software SPI Initialisation


			return 1;
			break;
	}
	return 0; //Initialisation failed!
}

/* Creates new instance of OLED display
// ptr = Pointer to SPI_Handle of desired SPI peripheral
// sizex = Size of OLED display in pixels horizontally
// sizey = Size of OLED display in pixels vertically
// returns OLED struct
// OLED->Status will return FAIL when problem occurs.
// OLED->Stat_Msg will a char* pointer containing error message or "Normal" if OK */
struct OLED *OLED_Create(struct OLED *myDisplay, uint8_t size_x, uint8_t size_y) //Set-up library
{
	//Initialise OLED ---------------------------------------------------------------
	myDisplay->Interface = HARD_SPI; //Set desired interface
	myDisplay->SizeX = size_x; //Set x dimension
	myDisplay->SizeY = size_y; //Set y dimension

	//ERROR HANDLING -----------------------------------------------------------------
	//Check that arguments are valid, if not return OLED struct with FAIL status
	if ((size_x <= 0) | (size_y <= 0))
	{
		if (size_x <= 0)
		{
			myDisplay->Stat_Msg = err_xsize;
			myDisplay->Status = FAIL;
		}
		if (size_y <= 0)
		{
			myDisplay->Stat_Msg = err_ysize;
			myDisplay->Status = FAIL;
		}
		return myDisplay;
	}

	//Check that SPI peripheral is ready and has no errors
	if (myDisplay->spih->State == HAL_SPI_STATE_RESET)
	{
		myDisplay->Stat_Msg = err_init;
		myDisplay->Status = FAIL;
		return myDisplay;
	}
	if (myDisplay->spih->State == HAL_SPI_STATE_ERROR)
	{
		myDisplay->Stat_Msg = err_error;
		myDisplay->Status = FAIL;
		return myDisplay;
	}

	//Return updated OLED struct
	return myDisplay;
}

