/**
  ******************************************************************************
  * @file     FXT_OLED.h
  * @author   William De Vos - Foxtronics 2022
  * @version  V1.0
  * @date     12/03/2022 15:28:17
  * @brief    Header for FXT_OLED.c
  ******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* TypeDefs ------------------------------------------------------------------*/
typedef enum {OK,FAIL} status; //Status enum, note if not defined status will default to 0
typedef enum {SOFT_SPI, HARD_SPI, PAR_8, PAR_16} con_type; //Connection type for OLED

/* External variables --------------------------------------------------------*/


/* Structs -------------------------------------------------------------------*/

// OLED Struct - contains variables relating to OLED function for instansization
// Arguments
// *spih - pointer to hardware SPI handler, pass &hspi to this argument
// sizex - The size of the OLED display along the x axis in pixels
// sizey - The size of the OLED display along the y axis in pixels
// Status - This value will be set to either OK or FAIL (see status enum)
// Status_Message[] - String containing messages relating to Status state
struct OLED
{
	con_type Interface;
	SPI_HandleTypeDef *spih;
	uint8_t SizeX;
	uint8_t SizeY;
	status Status;
	char* Stat_Msg; //Pointer to status message string
};
